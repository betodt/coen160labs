package edu.scu.coen160.lab7;

/**
 * @(#)DataGetter.java
 *
 *
 * @author 
 * @version 1.00 2012/2/27
 */


public interface DataGetter {
    
    public void readDataFromFile(String fileName);
}