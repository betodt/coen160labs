package edu.scu.coen160.lab2_exercises;

// Uncomment the lines as you compile each of the exercises.
public class Main {
       
    public static void main(String[] args) {
        Exercise1.tester1();
        Exercise1.tester2();
        Exercise2.tester();
        Exercise3.tester();
        Exercise4.tester();
        //Exercise5.tester();
    }
}
