package edu.scu.coen160.lab3;


// Uncomment the lines as you compile each of the exercises.
public class Main {
       
    public static void main(String[] args) {
        Lab3_Q1.q1();
        Lab3_Q2.q2();
        Lab3_Q3.q3();
		Lab3_Q4.q4();
    }
}
